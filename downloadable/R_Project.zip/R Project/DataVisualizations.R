## LOADING PACKAGES
# loading and shaping data
library(readr)
library(dplyr)
library(haven)

# data sources
library(gapminder)
library(palmerpenguins)

# general data visualisation
library(ggplot2)
library(ggridges)
library(ggthemes)
library(gghighlight)
library(ggforce)

## LOADING THE DATA 

penguins_df <- palmerpenguins::penguins

gapminder_df <- gapminder

##VIsualizing the data
#SCATTER
penguins_massVSflipsize <- ggplot(data = penguins_df,
       mapping = aes(x = body_mass_g,
                     y = flipper_length_mm,
                     color = species)) +
  geom_point() +
  scale_color_manual(values = c("#7fc97f", "blue", "#fdc086")) +
  labs(
    title = "Penguins, their mass and their flippers",
    subtitle = "The positive relationship between body mass and flipper size",
    caption = "Data: Gorman, Williams & Fraser (2014)",
    x = "Body mass (g)",
    y = "Flipper length (mm)",
    color = ""
  ) +
  theme_minimal()

#Saving (exporting) visualization
# ggsave(penguins_massVSflipsize, filename = "save/here/my_plot.png", 
       # dpi = 320, width = 120, height = 120)

#BAR
#subsetting 
penguins_sum <- penguins_df %>% 
  group_by(species) %>% 
  summarise(avg_bill_length = mean(bill_length_mm, na.rm = TRUE))
#visual
penguins_avg_bill_length_by_species <- ggplot(penguins_sum, aes(species, avg_bill_length)) +
  geom_bar(stat = "identity") +
  coord_flip()
# ggsave(penguins_avg_bill_length_by_species, 
# filename = "save/here/my_plot.png", 
# dpi = 320, width = 120, height = 120)

#HEATMAP
#subsetting and visualizing
gapminder_heatmap_yearVS_countryByGDP <- gapminder_df %>% 
  filter(continent == "Europe") %>% 
  ggplot(aes(year, reorder(country, gdpPercap), fill = gdpPercap)) +
  geom_tile(color = "grey")

# ggsave(gapminder_heatmap_yearVS_countryByGDP, 
# filename = "save/here/my_plot.png", 
# dpi = 320, width = 120, height = 120)

#DISTRIBUTIONS
#HISTOGRAM
ggplot(gapminder_df, aes(x = lifeExp, fill = continent)) +
  geom_histogram()

#BOXPLOT and JITTER PLOT
ggplot(penguins_df, aes(x = species, y = body_mass_g)) +
  geom_boxplot(outlier.color = "orange") + 
  geom_jitter(alpha = 0.25)

#only for illustrative purposes
# scatter with linear regression line
ggplot(data = gapminder_df,
       mapping = aes(x = lifeExp,
                     y = gdpPercap,
                     color = continent)) +
  geom_point(alpha = 0.5) + 
  geom_smooth(method = "lm", se = TRUE, color = "black") +
  scale_y_log10() +
  labs(
    y = "GDP per capita", 
    x = "Life expectancy",
    title = "Connection between GDP and Life expectancy",
    subtitle = "Points are country-years",
    caption = "Source: Gapminder"
  )
#
ggplot(penguins_df, aes(x = body_mass_g, y = flipper_length_mm, color = species, shape = species)) +
  geom_point() +
  labs(
    title = "Penguins, their mass and their flippers",
    subtitle = "The positive relationship between body mass and flipper size",
    caption = "Data: Gorman, Williams & Fraser (2014)",
    x = "Body mass (g)",
    y = "Flipper length (mm)",
    color = ""
  ) +
  scale_color_brewer(name = "Species", palette = "Set2") +
  scale_shape(guide = FALSE) +
  theme(
    axis.ticks = element_blank(), # removing axis ticks
    panel.grid.major = element_line(color = "grey", size = 0.1, linetype = "dotted"), # recoloring the panel grids
    panel.background = element_blank(),
    axis.line = element_line(colour = "grey"),
    legend.title = element_text(size = 12), # setting the legends text size
    text = element_text(face = "plain", family = "sans"), # setting global text options for our plot
    legend.key=element_blank(),
    legend.position = "bottom"
  )


